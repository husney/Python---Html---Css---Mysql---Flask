from setuptools import setup

setup(
    name="PaqueteVehiculo",
    version="1.0",
    description="Clase Vehiculo",
    author="Husney",
    author_email="usneibayon@gmail.com",
    url="HusneyRincon@github.io",
    packages=[ "Modulos.paquete1.sup_paquete"]
     

)